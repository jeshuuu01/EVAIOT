package com.example.powertrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.powertrack.datos.Repositorio;
import com.example.powertrack.model.Registro;
import com.example.powertrack.model.Sensor;
import com.example.powertrack.model.Ubicacion;
import com.example.powertrack.model.Tipo;

import java.util.Date;
import java.util.List;

public class SensoresActivity extends AppCompatActivity {

    private EditText nombreSensorEditText;
    private EditText modeloSensorEditText;
    private EditText lecturaActualEditText;
    private EditText idealEditText;
    private EditText descripcionSensorEditText;
    private Spinner ubicacionSpinner;
    private Spinner tipoSensorSpinner;
    private Button ingresarSensorButton;
    private Button verSensoresButton;

    private List<Sensor> sensores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensores);

        sensores = Repositorio.getInstance().sensores;

        nombreSensorEditText = findViewById(R.id.nombreAparatoEditText);
        modeloSensorEditText = findViewById(R.id.modeloSensorEditText);
        lecturaActualEditText = findViewById(R.id.lecturaActualEditText);
        idealEditText = findViewById(R.id.idealEditText);
        descripcionSensorEditText = findViewById(R.id.descripcionEditText);
        ubicacionSpinner = findViewById(R.id.ubicacionSpinner);
        tipoSensorSpinner = findViewById(R.id.tipoSensorSpinner);
        ingresarSensorButton = findViewById(R.id.ingresarSensorButton);
        verSensoresButton = findViewById(R.id.verSensoresButton);

        // Configuración de adaptadores para spinners
        List<Ubicacion> ubicaciones = Repositorio.getInstance().ubicaciones;
        ArrayAdapter<Ubicacion> ubicacionAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, ubicaciones);
        ubicacionSpinner.setAdapter(ubicacionAdapter);

        List<Tipo> tipos = Repositorio.getInstance().tipos;
        ArrayAdapter<Tipo> tipoAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, tipos);
        tipoSensorSpinner.setAdapter(tipoAdapter);

        ingresarSensorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = nombreSensorEditText.getText().toString().trim();
                String modelo = modeloSensorEditText.getText().toString().trim();
                String lecturaTexto = lecturaActualEditText.getText().toString().trim();
                String idealTexto = idealEditText.getText().toString().trim();
                String descripcion = descripcionSensorEditText.getText().toString().trim();

                float lecturaActual = lecturaTexto.isEmpty() ? 0.0f : Float.parseFloat(lecturaTexto);
                float ideal = idealTexto.isEmpty() ? 0.0f : Float.parseFloat(idealTexto);

                Ubicacion ubicacion = (Ubicacion) ubicacionSpinner.getSelectedItem();
                Tipo tipo = (Tipo) tipoSensorSpinner.getSelectedItem();

                if (!esNombreValido(nombre)) {
                    Toast.makeText(SensoresActivity.this, "El nombre debe tener entre 5 y 15 caracteres.", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!esDescripcionValida(descripcion)) {
                    Toast.makeText(SensoresActivity.this, "La descripción no debe exceder los 30 caracteres.", Toast.LENGTH_LONG).show();
                    return;
                }

                Sensor nuevoSensor = new Sensor(nombre, modelo, lecturaActual, ideal, ubicacion, tipo, descripcion);
                Registro nuevoRegistro = new Registro(lecturaActual, nuevoSensor, new Date());
                nuevoSensor.agregarRegistro(nuevoRegistro);

                sensores.add(nuevoSensor);

                Toast.makeText(SensoresActivity.this, "Sensor ingresado correctamente", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        verSensoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SensoresActivity.this, ListaSensoresActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean esNombreValido(String nombre) {
        return nombre.length() >= 5 && nombre.length() <= 15;
    }

    private boolean esDescripcionValida(String descripcion) {
        return descripcion.isEmpty() || descripcion.length() <= 30;
    }
}
