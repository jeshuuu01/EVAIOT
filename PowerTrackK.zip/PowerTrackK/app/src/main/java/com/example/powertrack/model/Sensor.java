package com.example.powertrack.model;

import java.util.ArrayList;
import java.util.List;

public class Sensor {
    private String nombre;
    private String modelo;
    private float lecturaActual;
    private float ideal;
    private Ubicacion ubicacion;
    private Tipo tipo;
    private String descripcion;
    private List<Registro> registros;

    public Sensor(String nombre, String modelo, float lecturaActual, float ideal, Ubicacion ubicacion, Tipo tipo, String descripcion) {
        this.nombre = nombre;
        this.modelo = modelo;
        this.lecturaActual = lecturaActual;
        this.ideal = ideal;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.registros = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getModelo() {
        return modelo;
    }

    public float getLecturaActual() {
        return lecturaActual;
    }

    public float getIdeal() {
        return ideal;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Registro> getRegistros() {
        return registros;
    }

    public void agregarRegistro(Registro registro) {
        registros.add(registro);
    }
}
