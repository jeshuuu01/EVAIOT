package com.example.powertrack.model;

import java.util.Date;

public class Registro {
    private float valor;
    private Date fechaHora;
    private Sensor sensor;

    public Registro(float valor, Sensor sensor, Date fechaHora) {
        this.valor = valor;
        this.sensor = sensor;
        this.fechaHora = fechaHora;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public Sensor getSensor() {
        return sensor;
    }

    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }
}
