package com.example.powertrack;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.powertrack.datos.Repositorio;

import com.example.powertrack.adapters.SensoresAdapter;
import com.example.powertrack.model.Sensor;

import java.util.List;

public class ListaSensoresActivity extends AppCompatActivity {

    private RecyclerView sensoresRecyclerView;
    private SensoresAdapter sensoresAdapter;
    private List<Sensor> sensores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_sensores);

        sensoresRecyclerView = findViewById(R.id.listaSensoresRecyclerView);
        sensoresRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        sensores = Repositorio.getInstance().sensores;
        sensoresAdapter = new SensoresAdapter(sensores);
        sensoresRecyclerView.setAdapter(sensoresAdapter);
    }
}
