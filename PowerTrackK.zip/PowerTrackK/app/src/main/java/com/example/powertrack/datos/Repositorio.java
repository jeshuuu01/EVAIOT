// Archivo: Repositorio.java
package com.example.powertrack.datos;

import com.example.powertrack.model.Sensor;
import com.example.powertrack.model.Ubicacion;
import com.example.powertrack.model.Tipo;

import java.util.ArrayList;
import java.util.List;

public class Repositorio {

    private static Repositorio instance = null;
    public List<Tipo> tipos; // Cambiado a Tipo
    public List<Sensor> sensores;
    public List<Ubicacion> ubicaciones;

    protected Repositorio() {
        sensores = new ArrayList<>();
        ubicaciones = new ArrayList<>();
        tipos = new ArrayList<>();

        // Agregar tipos de ejemplo
        Tipo tipoTemperatura = new Tipo("Temperatura");
        Tipo tipoHumedad = new Tipo("Humedad");

        tipos.add(tipoTemperatura);
        tipos.add(tipoHumedad);

        // Agregar ubicaciones de ejemplo
        ubicaciones.add(new Ubicacion("Invernadero 1", "Sección A"));
        ubicaciones.add(new Ubicacion("Invernadero 2", "Sección B"));
        ubicaciones.add(new Ubicacion("Invernadero 3", "Sección C"));

        // Agregar sensores de ejemplo
        sensores.add(new Sensor("Sensor 1", "Modelo A", 22.5f, 25.0f, ubicaciones.get(0), tipoTemperatura, "Sensor de temperatura en invernadero 1"));
        sensores.add(new Sensor("Sensor 2", "Modelo B", 18.0f, 20.0f, ubicaciones.get(1), tipoHumedad, "Sensor de humedad en invernadero 2"));
    }

    public static synchronized Repositorio getInstance() {
        if (instance == null) {
            instance = new Repositorio();
        }
        return instance;
    }
}
