package com.example.powertrack.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.powertrack.R;
import com.example.powertrack.model.Registro;
import com.example.powertrack.model.Sensor;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class SensoresAdapter extends RecyclerView.Adapter<SensoresAdapter.ViewHolder> {

    private List<Sensor> sensores;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());

    public SensoresAdapter(List<Sensor> sensores) {
        this.sensores = sensores;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Sensor sensor = sensores.get(position);

        holder.textViewNombre.setText("Nombre: " + sensor.getNombre());
        holder.textViewModelo.setText("Modelo: " + sensor.getModelo());
        holder.textViewDescripcion.setText("Descripción: " + (sensor.getDescripcion() != null ? sensor.getDescripcion() : "N/A"));
        holder.textViewLecturaActual.setText("Lectura Actual: " + sensor.getLecturaActual());
        holder.textViewIdeal.setText("Valor Ideal: " + sensor.getIdeal());

        // Construir los registros sin duplicar el título "Lectura"
        StringBuilder registrosInfo = new StringBuilder();
        for (Registro registro : sensor.getRegistros()) {
            registrosInfo.append("Instante: ")
                    .append(dateFormat.format(registro.getFechaHora()))
                    .append("\n");
        }

        // Asignar el texto al TextView, eliminando el último salto de línea si existe
        holder.textViewRegistros.setText(registrosInfo.toString().trim());
    }

    @Override
    public int getItemCount() {
        return sensores.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textViewNombre;
        private TextView textViewModelo;
        private TextView textViewDescripcion;
        private TextView textViewLecturaActual;
        private TextView textViewIdeal;
        private TextView textViewRegistros;

        public ViewHolder(View view) {
            super(view);
            textViewNombre = view.findViewById(R.id.textViewNombre);
            textViewModelo = view.findViewById(R.id.textViewModelo);
            textViewDescripcion = view.findViewById(R.id.textViewDescripcion);
            textViewLecturaActual = view.findViewById(R.id.textViewLecturaActual);
            textViewIdeal = view.findViewById(R.id.textViewIdeal);
            textViewRegistros = view.findViewById(R.id.textViewRegistros);
        }
    }
}
