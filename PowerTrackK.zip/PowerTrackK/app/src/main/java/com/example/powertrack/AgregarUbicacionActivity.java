package com.example.powertrack;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.powertrack.datos.Repositorio;
import com.example.powertrack.model.Ubicacion;
import java.util.Arrays;
import java.util.List;

public class AgregarUbicacionActivity extends AppCompatActivity {

    private EditText nombreUbicacionEditText;
    private EditText descripcionUbicacionEditText;
    private Spinner ubicacionSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_ubicacion);

        nombreUbicacionEditText = findViewById(R.id.nombreUbicacionEditText);
        descripcionUbicacionEditText = findViewById(R.id.descripcionUbicacionEditText);
        ubicacionSpinner = findViewById(R.id.ubicacionSpinner);
        Button guardarUbicacionButton = findViewById(R.id.guardarUbicacionButton);

        // Llenado con datos de muestra en el Spinner
        List<String> datosMuestra = Arrays.asList("Invernadero 1", "Invernadero 2", "Invernadero 3");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, datosMuestra);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        ubicacionSpinner.setAdapter(adapter);

        guardarUbicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = nombreUbicacionEditText.getText().toString().trim();
                String descripcion = descripcionUbicacionEditText.getText().toString().trim();

                if (nombre.isEmpty()) {
                    Toast.makeText(AgregarUbicacionActivity.this, "Por favor, ingresa un nombre para la ubicación", Toast.LENGTH_SHORT).show();
                } else if (descripcion.length() > 30) {
                    Toast.makeText(AgregarUbicacionActivity.this, "La descripción no puede tener más de 30 caracteres", Toast.LENGTH_SHORT).show();
                } else {
                    Repositorio.getInstance().ubicaciones.add(new Ubicacion(nombre, descripcion));
                    Toast.makeText(AgregarUbicacionActivity.this, "Ubicación agregada", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}
